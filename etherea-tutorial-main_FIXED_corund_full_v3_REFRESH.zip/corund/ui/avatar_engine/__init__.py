# Avatar Engine package (multi-avatars + dynamic backgrounds)
