from __future__ import annotations

# Backward-compatible import path.
from corund.voice_engine import VoiceEngine, get_voice_engine

__all__ = ["VoiceEngine", "get_voice_engine"]
